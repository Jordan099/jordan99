/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FactoryMethod;

/**
 *
 * @author jorda
 */
public class Paquete20 extends PlanTelcel{
    
    @Override
    public void descripcionPaquete(){
        System.out.println("*------ PAQUETE 20$ ACTIVADO ------------*");
        System.out.println("*|    20 MB                             |*");
        System.out.println("*|    Minutos y mensajes ilimitados     |*");
        System.out.println("*|    No aplica redes sociales          |*");
        System.out.println("*|    Vigencia su paquete es de 2 dias *| ");
        System.out.println("*----------------------------------------*");
       
    }
    
}
